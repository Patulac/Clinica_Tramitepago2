package prykualiatl;


public class CMain
{
    public CMain()
    {
    }

    public static void main(String[] args)
    {
        new frmSplash().setVisible(true); 
    }
}
