import React from 'react'
import ReactDOM from 'react-dom/client'
import Pasarelapse from './Pasarelapse'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
   <Pasarelapse>


   </Pasarelapse>

  </React.StrictMode>
)